// replace images when the page loads

// replace text in the page when it loads

// $('body').children().each(function () {
// 	// replace the '@' sign with a '$' sign
// 	$(this).html( $(this).html().replace(a b c d e f g h i j k l m n o p q r s t u v w x y z,'spin') );
// });

// when you click on an image hide it using CSS

// $('img').click(function() {
// 	$(this).addClass('hide');
// });

// when you click on the page 'body' apply .gradient to it from the CSS

// $('body').click(function() {
// 	$(this).addClass('gradient');
// });

$('img').click(function() {
    $(this).addClass('rotate');
})

// Facebook

//$('img').attr('src', 'https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('div').attr('src', 'https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('body').attr('src', 'https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('#pinnedNav.homeSideNav').attr('src', 'https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('#appsNav').attr('src','https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('#createNav').attr('src','https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('.homeSideNav').attr('src','https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');
// $('.linkWrap.noCounts').attr('src','https://cdn.abcotvs.com/dip/images/3324594_041018-kgo-ap-mark-zuckerberg-congress-testify-img.jpg');

$('div').click(function() {
    $(this).addClass('rotate');
});

// $(body).click(function() {
// 	$(this).addClass('.transparent')
// });

// $(window).scroll(function(){
	
// })

// $('div').click(function() {
// 	$(this).fadeOut();
// });

// $('img').click(function() {
//  $(this).addClass('dog');
// });


